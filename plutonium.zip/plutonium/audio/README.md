This directory may, in future, contain a full copy of the `audio` directory from 5etools. For now, it houses just one file.
